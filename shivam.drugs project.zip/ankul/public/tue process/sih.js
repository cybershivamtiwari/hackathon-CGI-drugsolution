function popup()
{

   document.querySelector(".popup").style.display="block";
   document.querySelector(".button").style.display="none";

} 



let userdatabase=[{
  email: 'karansingh.5@gmail.com',
  password: 'KaranS@22',
  Gender: 'male',
  age: 19,
  name: 'Karan Singh'
},
{email: 'rohankumar555@gmail.com',
password: 'RohanK@543',
Gender: 'male',
age: 20,
name: 'Rohan Kumar'},{

},
{
  email: 'prashantkumar223@gmail.com',
  password: 'PrashantK@22',
  Gender: 'male',
  age: 20,
  name: 'Prashant Kumar'
},
{
  email: 'mohitarora334@gmail.com',
  password: 'MohitA@334',
  Gender: 'male',
  age: 20,
  name: 'Mohit Arora'
},
{
  email: 'gauravsingh.44@gmail.com',
  password: 'GauravSgh@445',
  Gender: 'male',
  age: 21,
  name: 'Gaurav singh'
},
{
  email: 'pranavkumar223@gmail.com',
  assword: 'PranavKr@433',
  Gender: 'male',
  age: 21,
  name: 'Pranav Kumar'
},
{
  email: 'Garvsinha77@gmail.com',
  password:"123",
  /*password: 'Garvsinha.443',*/
  Gender: 'male',
  age: 23,
  name: 'Garv Sinha'
}
];

var Email;
var Password;
console.log(typeof userdatabase[0].email)
console.log(typeof  userdatabase[0].password)
console.log( userdatabase[0].email)
console.log(  userdatabase[0].password)
var flag=0;
function Login()
{
  Email =document.getElementsByClassName("Email")[0].value
  Password=document.getElementsByClassName("Password")[0].value
console.log( Email)
console.log( Password)
console.log( typeof Email)
console.log( typeof Password)
  for(let i=0; i<userdatabase.length; i++)
  {
    let user=userdatabase[0];

    if(user.email==Email&&user.password==Password)
    {console.log(true);
    flag=1;}
    else
    console.log(false);
  }
  console.log(flag)
if(flag==1)
{
  document.querySelector(".popup").style.display="none";
}
else
{
  document.querySelector(".invalid").style.display="block";
}
};
function removeinvalid()
{
  document.querySelector(".invalid").style.display="none";

}











